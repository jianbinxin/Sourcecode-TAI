#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import math
import rospy
from std_msgs.msg import Float32MultiArray

NUM_ROBOTS = 3

robot_x = [0.0] * NUM_ROBOTS
robot_y = [0.0] * NUM_ROBOTS
robot_yaw = [0.0] * NUM_ROBOTS
robot_linear = [0.0] * NUM_ROBOTS
robot_angular = [0.0] * NUM_ROBOTS

# 距离矩阵和上一次距离矩阵
robotDis = [[0.0 for _ in range(NUM_ROBOTS)] for _ in range(NUM_ROBOTS)]
last_robotDis = [[0.0 for _ in range(NUM_ROBOTS)] for _ in range(NUM_ROBOTS)]

choices = [0] * NUM_ROBOTS

def make_state_callback(idx):
    def callback(msg):
        robot_x[idx] = msg.data[0]
        robot_y[idx] = msg.data[1]
        robot_yaw[idx] = msg.data[2]
        robot_linear[idx] = msg.data[3]
        robot_angular[idx] = msg.data[4]
    return callback

rospy.init_node('communication_and_select_node')

subs = []
for i in range(NUM_ROBOTS):
    subs.append(rospy.Subscriber('/robot_%d/states' % i, Float32MultiArray, make_state_callback(i), queue_size=5))

pubs = []
pub_states = []
for i in range(NUM_ROBOTS):
    pubs.append(rospy.Publisher('/robot_%d/choice' % i, Float32MultiArray, queue_size=5))
    msg = Float32MultiArray()
    msg.data = [0.0] * (NUM_ROBOTS - 1 + 1)  # 距离+1个choice
    pub_states.append(msg)

ros_rate = rospy.Rate(100)
while not rospy.is_shutdown():
    # 计算距离
    for i in range(NUM_ROBOTS):
        for j in range(NUM_ROBOTS):
            if i != j:
                robotDis[i][j] = math.hypot(robot_x[i] - robot_x[j], robot_y[i] - robot_y[j])

    # 选择逻辑
    for i in range(NUM_ROBOTS):
        min_dis = float('inf')
        min_j = -1
        for j in range(NUM_ROBOTS):
            if i != j and robotDis[i][j] < min_dis:
                min_dis = robotDis[i][j]
                min_j = j
        if min_j != -1 and min_dis < 1.2 and min_dis < last_robotDis[i][min_j]:
            choices[i] = 1
        else:
            choices[i] = 0

    # 发布消息
    for i in range(NUM_ROBOTS):
        k = 0
        for j in range(NUM_ROBOTS):
            if i != j:
                pub_states[i].data[k] = robotDis[i][j]
                k += 1
        pub_states[i].data[-1] = choices[i]
        pubs[i].publish(pub_states[i])

    # 更新last距离
    for i in range(NUM_ROBOTS):
        for j in range(NUM_ROBOTS):
            last_robotDis[i][j] = robotDis[i][j]

    ros_rate.sleep()