#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from rosgraph.network import read_ros_handshake_header
import rospy
import threading
from geometry_msgs.msg import Twist, Point, Pose, PoseStamped
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry, Path
from std_srvs.srv import Empty
from gazebo_msgs.srv import SpawnModel, DeleteModel

from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest
from gazebo_msgs.msg import ModelState

import sys
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Pose, PoseWithCovarianceStamped, Point, Quaternion, Twist,PoseStamped
from nav_msgs.msg import Path
from std_srvs.srv import Empty

from navigation_internal import Agent
from mpi4py import MPI

#!/usr/bin/env python3
import time
import numpy as np
import matplotlib.pyplot as plt

from math import sin, cos, atan2, sqrt, fabs, hypot

# build goal set, where the location of each goal needs to be 0.5m far from obstacles, 
# so as to enable all goals accessible
# goal_set for test_world_6_6
goal_set = [[ -2.5,  1.5], [ -0.5,  1.5], [ 1.0,  1.5], [ 2.0,  1.5], 
            [ -2.5,  0.0], [-1.0,  0.0], [0.0,  0.0], [1.0,  0.0], 
            [2.0,  0.0], [-2.0,  -1.5],[-1.0,  -1.5], [2.5,  -1.5],
            [-2.5,  -2.5], [-1.5,  -2.5],[0.5,  -2.5], [2.0,  -2.5],
            [-2.5,  2.5], [1.5,  -2.5],[0.0,  2.5], [2.5,  2.5]]
goal_set_length = len(goal_set)
global index_robot_0,index_goal_0,index_robot_1,index_goal_1
index_robot_0 =0
index_goal_0 = 0
index_robot_1 = 0
index_goal_1 = 0
# build goal set, where the location of each goal needs to be 0.5m far from obstacles, 
# so as to enable all goals accessible

# lase scan parameters
# number of all laser beams
n_all_laser = 360
laser_angle_resolute = np.pi / (n_all_laser - 1)
# number of used laser beams
n_used_laser = 180
n_used_laser2 = 36
laser_interval = 1 #int((n_all_laser - 1) / (n_used_laser - 1))
laser_interval2 = 5
# in Gazebo, the actual minimum laser range is 0.25m
# here, a little larger range is chosen for detecting collision
laser_min_range = 0.17
# lase scan parameters

# used for visualizing goal
goal_model_dir = '/home/xutao/turtlebot3_HDRL/src/rl_navigation/urdf/Target/model.sdf'
# used for visualizing goal

class Env:
    def __init__(self, index, comm):
        #MPI parameters
        self.index = index
        self.comm = comm

        if self.index == 0:
            self.agent_low = Agent()
        else:
            self.agent_low = None

        #init node
        node_name = 'Gazebo_Env_' + str(index)
        rospy.init_node(node_name, anonymous=None)      

        # used to reset robot state       
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'robot_'+ str(index)
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.0
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['wheel_left_joint', 'wheel_right_joint']
        self.starting_pos = np.array([0.0, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'robot_'+ str(index)
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos
        # used to reset robot state

        # used to pause and unpause simulation
        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics', Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        # used to pause and unpause simulation

        # visualize goal in Gazebo
        self.goal = rospy.ServiceProxy('/gazebo/spawn_sdf_model', SpawnModel)
        self.del_model = rospy.ServiceProxy('/gazebo/delete_model', DeleteModel)
        # visualize goal in Gazebo

        # robot pose
        self.robot_pose = np.zeros(3)
        # relative pose of sub_goal in robot frame
        self.rel_theta = 0.
        self.rel_dis = 0.
        self.rel_dis_last = 0.

        #other robot
        self.dis_to_other0 = 0.
        #self.dis_to_other1 = 0.
        self.policy_level = 0
        self.radius = 0.15

        # avoid disorder of data in different threadings
        self.state_lock = threading.Lock()
        # avoid disorder of data in different threadings

        # laser scan overservation for RL
        self.used_scan = np.zeros(n_used_laser, dtype=np.float64)
        self.used_scan_low = np.zeros(n_used_laser2, dtype=np.float64)
        # laser scan overservation for RL

        
        # goal position, x, y, which is randomly set
        self.goal_position = np.zeros(2)
        self.goal_position_pose = Pose()
        self.sub_goal_position = np.zeros(2)
        self.sub_goal_x = 0.
        self.sub_goal_y = 0.
        
        self.goal_count = 0
        self.goal_lock = threading.Lock()
        self.sub_goal_lock = threading.Lock()
        self.pose = PoseStamped()
        self.pose.header.frame_id = "map"
        self.pose.pose.position.x = 0.
        self.pose.pose.position.y = 0.
        self.pose.pose.position.z = 0.
        self.pose.pose.orientation.x = 0.
        self.pose.pose.orientation.y = 0.
        self.pose.pose.orientation.z = 0.
        self.pose.pose.orientation.w = 1
        # relative distance from the goal to the robot
        self.rel_dis_final_goal = 0.
        
        # if the distance from the robot to the goal is less than threshold_arrive,
        # then the robot successfully arrives the target
        self.threshold_arrive = 0.1
        # used to record the minimum value of all laser beams
        self.min_scan_range = laser_min_range
       
        # motion parameters
        # how far to select the sub goal
        self.look_ahead = 0.5
        # control gain for angular velocity
        self.angle_to_velocity = 0.8
        self.error_integral = 0
        self.prev_error = 0
        self.max_angular_velocity = 0.6
        self.max_linear_velocity = 0.2
        self.control_frequency = 10
        self.dt = 1.0 / self.control_frequency
        self.current_step = 0
        self.linear_v_current = 0.
        self.angular_v_current = 0.
        self.linear_v_last = 0.0
        self.angular_v_last = 0.0
        self.linear_acc_max = 0.3
        self.angular_acc_max = 0.4
        # motion parameters

        # subscribe and publish
        robot_states_topic = 'robot_' + str(index) +'/states'
        self.sub_robot_states = rospy.Subscriber(robot_states_topic, Float32MultiArray, \
                            self.StateCallback, queue_size=5)

        global_path_topic = 'robot_' + str(index) +'/move_base/NavfnROS/plan'                  
        self.sub_global_path = rospy.Subscriber(global_path_topic, Path, \
                            self.GlobalPathCallback, queue_size=5)
                        
        other_robot_state_topic  = 'robot_' + str(index) +'/choice' 
        self.sub_robot_states = rospy.Subscriber(other_robot_state_topic, Float32MultiArray, \
                            self.OtherStateCallback, queue_size=5)

        cmd_vel_topic = 'robot_' + str(index) +'/cmd_vel'     
        self.pub_cmd_vel = rospy.Publisher(cmd_vel_topic, Twist, queue_size=10)

        goal_point_topic = 'robot_' + str(index) +'/move_base_simple/goal'
        self.pub_cmd_pos = rospy.Publisher(goal_point_topic, PoseStamped, queue_size=5)
        # subscribe and publish

        # thread of publishing goal pose
        self.thread_pub_goal = threading.Thread(target=self.pub_goal_thread)
        self.thread_pub_goal.start()

    def pub_goal_thread(self):
        rate = rospy.Rate(2)  
        while not rospy.is_shutdown():
            self.pose.pose.position.x = self.goal_position[0]
            self.pose.pose.position.y = self.goal_position[1]
            self.pose.header.stamp = rospy.Time.now()

            if self.min_scan_range > 0.5:
                self.pub_cmd_pos.publish(self.pose)
                #print('goal:',self.pose.pose.position.x,self.pose.pose.position.y)
            rate.sleep()
        
    def GlobalPathCallback(self, path_data):
        dis_sub_goal = 0.0
        for i in range(len(path_data.poses)):
            robot_x = self.robot_pose[0]
            robot_y = self.robot_pose[1]
            x = path_data.poses[i].pose.position.x
            y = path_data.poses[i].pose.position.y
            dis_sub_goal = hypot(x - robot_x, y - robot_y)
            if dis_sub_goal >= self.look_ahead:
                self.sub_goal_lock.acquire()
                self.sub_goal_position[0] = x
                self.sub_goal_position[1] = y
                self.sub_goal_lock.release()
                break
        if (len(path_data.poses)):
            if dis_sub_goal < self.look_ahead:
                self.sub_goal_lock.acquire()
                self.sub_goal_position[0] = path_data.poses[-1].pose.position.x
                self.sub_goal_position[1] = path_data.poses[-1].pose.position.y
                self.sub_goal_lock.release()
                #print('subgoal: ', self.sub_goal_position)

    def StateCallback(self, msg):
        rel_dis_final_goal = hypot(self.goal_position[0] - msg.data[0], \
                                   self.goal_position[1] - msg.data[1])
        self.state_lock.acquire()
        self.robot_pose[0] = msg.data[0]
        self.robot_pose[1] = msg.data[1]
        self.robot_pose[2] = msg.data[2]
        self.linear_v_current = msg.data[3]
        self.angular_v_current = msg.data[4]
        self.rel_dis_final_goal = rel_dis_final_goal
        self.state_lock.release()           

    def OtherStateCallback(self, msg):
        self.state_lock.acquire()
        self.dis_to_other0 = msg.data[0]
        #self.dis_to_other1 = msg.data[1]
        self.policy_level = int(msg.data[1])
        self.state_lock.release()     

    def getState(self, scan):
        scan_range = []
        # print(scan)
        # print(len(scan.ranges))
        done = False
        arrive = False

        robot_x = self.robot_pose[0]
        robot_y = self.robot_pose[1]
        robot_yaw = self.robot_pose[2]
        linear_v = self.linear_v_current
        angular_v = self.angular_v_current
        rel_dis_final_goal = self.rel_dis_final_goal

        self.state_lock.acquire()
        self.min_scan_range = min(scan.ranges)
        self.state_lock.release()

        dx = self.sub_goal_x - robot_x
        dy = self.sub_goal_y - robot_y

        self.rel_dis = hypot(dx, dy)
        rel_theta = atan2(dy, dx) - robot_yaw
        if rel_theta < -np.pi:
            rel_theta += (2 * np.pi)
        if rel_theta > np.pi:
            rel_theta -= (2 * np.pi)
        self.rel_theta = rel_theta
        
        
        if (laser_min_range >= self.min_scan_range):
            done = True
        for i in range(len(scan.ranges)):
            if scan.ranges[i] == float('Inf') or scan.ranges[i] > 1.5:
                scan_range.append(1.5)
            elif np.isnan(scan.ranges[i]) or scan.ranges[i] < laser_min_range:
                scan_range.append(laser_min_range)
            else:
                scan_range.append(scan.ranges[i])
        
        scan_range_reduce = []
        scan_range_reduce2 = []

        j = 0
        # original scan: 360 dimensions
        # reduced scan: 180 dimnensions
        # while (j < len(scan_range)):
        #     scan_range_reduce.append(scan_range[j])
        #     j = j + laser_interval
        # print(laser_angle_resolute, laser_interval)
        for j in range(90, 270):
            scan_range_reduce.append(scan_range[j])

        jj = 0
        # original scan: 360 dimensions
        # reduced scan: 36 dimnensions
        # while (jj < len(scan_range) and len(scan_range_reduce2) < n_used_laser2):
        #     scan_range_reduce2.append(scan_range[jj])
        #     jj = jj + laser_interval2
        for jj in range(90, 270, laser_interval2):
            scan_range_reduce2.append(scan_range[jj])

        #print("scan1 len:",len(scan_range_reduce), "scan2 len:", len(scan_range_reduce2))
        if rel_dis_final_goal <= self.threshold_arrive or self.current_step == 500:            
            arrive = True

        return (np.array(scan_range_reduce), np.array(scan_range_reduce2), linear_v, angular_v, done, arrive)

    def step(self, action):
        reward = 0.0
        orientation_error = self.rel_theta
        # normalizing angle error to <-pi; pi>
        if orientation_error > np.pi:
            orientation_error = orientation_error - 2 * np.pi
        if orientation_error < -np.pi:
            orientation_error = orientation_error + 2 * np.pi

        linear_v = self.linear_v_current
        angular_v = self.angular_v_current
        state1_low = self.used_scan_low / 1.5               #36
        #print(len(state1_low),"state_low:",state1_low)
        state2_low = np.array([self.rel_dis / self.look_ahead, self.rel_theta / np.pi, linear_v, angular_v])
        state1_low_list = self.comm.gather(state1_low, root=0)
        #print("state_low_list:",state1_low_list)
        state2_low_list = self.comm.gather(state2_low, root=0)
        action_low_list = []
        if self.index == 0:
            action_low_0 = self.agent_low.model.get_action(state1_low_list[0], state2_low_list[0])
            action_low_1 = self.agent_low.model.get_action(state1_low_list[1], state2_low_list[1])
            #action_low_2 = self.agent_low.model.get_action(state1_low_list[2], state2_low_list[2])
            action_low_list = [action_low_0, action_low_1]
        action_low = self.comm.scatter(action_low_list, root=0)

        if self.policy_level == 1:
            #print("------external policy-------","Env:", self.index, self.dis_to_other0)
            linear_v = 0.0
            if action == 0:
                linear_v = 0.0
                reward -= 0.2         #-2(0.1-v)
            if action == 1:
                linear_v = 0.025
                reward -= 0.15
            if action == 2:
                linear_v = 0.05
                reward -= 0.10
            if action == 3:
                linear_v = 0.075
                reward -= 0.05
            if action == 4:
                linear_v = 0.10
            if action == 5:
                linear_v = 0.125
            if action == 6:
                linear_v = 0.15
            if action == 7:
                linear_v = 0.175
            if action == 8:
                linear_v = 0.20

            dis_to_other0 = self.dis_to_other0
            reward = reward - 0.10/ (dis_to_other0 - 2*self.radius) 

        elif self.policy_level == 0:
            #print("------internal policy-------","Env:", self.index, self.dis_to_other0)
            if action_low == 0:
                linear_v = 0.0
            if action_low == 1:
                linear_v = 0.05
            if action_low == 2:
                linear_v = 0.15
            if action_low == 3:
                linear_v = 0.20
        
        #print(orientation_error)
        if orientation_error > 0.35*np.pi or orientation_error < -0.35*np.pi:
            linear_v = 0.0

        # Constants for PID control
        kp = 1.2  # Proportional gain
        ki = 0.05  # Integral gain
        kd = 0.8  # Derivative gain
        # Variables for PID control
        self.error_integral += orientation_error  # Accumulate the error over time
        delta_error = orientation_error - self.prev_error  # Calculate the change in error
        #print(self.error_integral, delta_error)
        # Calculate the PID control signal
        angular_v = self.angle_to_velocity * (kp * orientation_error + ki * self.error_integral + kd * delta_error)
        # # Update the previous error for the next iteration
        self.prev_error = orientation_error

        if angular_v > self.max_angular_velocity:
            angular_v = self.max_angular_velocity
        if angular_v < -self.max_angular_velocity:
            angular_v = -self.max_angular_velocity

         # add noise
        velocity_var = np.random.normal(0, 0.05, 2)
        linear_v = linear_v + velocity_var[0] / 5
        if linear_v < 0:
            linear_v = 0
        if linear_v > self.max_linear_velocity:
            linear_v = self.max_linear_velocity
        angular_v = angular_v + velocity_var[1] / 2

        # publish velocity commands
        vel_cmd = Twist()
        vel_cmd.linear.x = linear_v
        vel_cmd.angular.z = angular_v
        self.pub_cmd_vel.publish(vel_cmd)
        # publish velocity commands

        # it continues 0.1s here to get laser data
        # laser scan frequency 10Hz
        # t1 = time.time()
        data = None
        while data is None:
            try:
                laser_topic = 'robot_' + str(self.index) +'/scan'
                data = rospy.wait_for_message(laser_topic, LaserScan, timeout=5)
            except:
                pass
        # t2 = time.time()
        # print(t2-t1)
        # it continues 0.1s here to get laser data

        done, arrive, arrive2 = False, False, False
        self.used_scan, self.used_scan_low, linear_v, angular_v, done, arrive = self.getState(data)

        if self.min_scan_range >= laser_min_range:
            reward = reward - (0.08 / self.min_scan_range) * laser_min_range
        rel_dis_delta = self.rel_dis_last - self.rel_dis
        reward = reward + 180.0 * rel_dis_delta
        self.rel_dis_last = self.rel_dis
        self.linear_v_last = linear_v
        self.angular_v_last = angular_v
            
        if arrive:
            # print('target arrived at: ', self.current_step)
            self.current_step = 0

        if done:
            # print('collision happened at: ', self.current_step)
            reward = -200                                                                                                                         
            self.current_step = 0 
        self.current_step = self.current_step + 1

        if self.current_step % (2 * self.control_frequency) == 0:
            arrive2 = True
            self.sub_goal_x = self.sub_goal_position[0]
            self.sub_goal_y = self.sub_goal_position[1]
            self.error_integral = 0
            self.prev_error = 0

            # print('sub goal: ', sub_goal_x, sub_goal_y)
            robot_x = self.robot_pose[0]
            robot_y = self.robot_pose[1]
            robot_yaw = self.robot_pose[2]
            dx = self.sub_goal_x - robot_x
            dy = self.sub_goal_y - robot_y
            self.rel_dis = hypot(dx, dy)
            self.rel_dis_last = self.rel_dis

            rel_theta = atan2(dy, dx) - robot_yaw
            if rel_theta < -np.pi:
                rel_theta += (2 * np.pi)
            if rel_theta > np.pi:
                rel_theta -= (2 * np.pi)
            self.rel_theta = rel_theta

        dis_to_other0 = self.dis_to_other0
        #dis_to_other1 = self.dis_to_other1
        if dis_to_other0  > 2.0:
            dis_to_other0 = 2.0
        # if dis_to_other1  > 2.0:
        #     dis_to_other1 = 2.0

        state1 = self.used_scan / 1.5
        state2 = np.array([self.rel_dis / self.look_ahead, self.rel_theta / np.pi, linear_v, angular_v])

        return state1, state2, reward, done, arrive, arrive2

    def reset(self, episode):
        # randomly set goal position and robot states
        index_robot_0 = int(np.random.randint(0, goal_set_length, size=1))
        index_goal_0 = int(np.random.randint(0, goal_set_length, size=1))
        index_robot_1 = int(np.random.randint(0, goal_set_length, size=1))
        index_goal_1 = int(np.random.randint(0, goal_set_length, size=1))
        if self.index == 0:
            # index_goal_robot_0 = np.random.randint(0, goal_set_length, size=2)
            # index_goal_0 = index_goal_robot_0[0]
            # index_robot_0 = index_goal_robot_0[1]
            while(index_goal_0 == index_robot_0):
                index_goal_robot_0 = np.random.randint(0, goal_set_length, size=2)
                index_goal_0 = index_goal_robot_0[0]
                index_robot_0 = index_goal_robot_0[1]
        if self.index == 1:
            # index_goal_robot_1 = np.random.randint(0, goal_set_length, size=2)
            # index_goal_1 = index_goal_robot_1[0]
            # index_robot_1 = index_goal_robot_1[1]
            while(index_goal_1 == index_robot_1):
                index_goal_robot_1 = np.random.randint(0, goal_set_length, size=2)
                index_goal_1 = index_goal_robot_1[0]
                index_robot_1 = index_goal_robot_1[1]

        while(index_goal_0 == index_goal_1 or index_robot_0 == index_robot_1):           
            if self.index == 0:
                index_goal_robot_0 = np.random.randint(0, goal_set_length, size=2)
                index_goal_0 = index_goal_robot_0[0]
                index_robot_0 = index_goal_robot_0[1]
                while(index_goal_0 == index_robot_0):
                    index_goal_robot_0 = np.random.randint(0, goal_set_length, size=2)
                    index_goal_0 = index_goal_robot_0[0]
                    index_robot_0 = index_goal_robot_0[1]
            if self.index == 1:
                index_goal_robot_1 = np.random.randint(0, goal_set_length, size=2)
                index_goal_1 = index_goal_robot_1[0]
                index_robot_1 = index_goal_robot_1[1]
                while(index_goal_1 == index_robot_1):
                    index_goal_robot_1 = np.random.randint(0, goal_set_length, size=2)
                    index_goal_1 = index_goal_robot_1[0]
                    index_robot_1 = index_goal_robot_1[1]

        if self.index == 0:
            self.goal_lock.acquire()
            self.goal_position[0] = goal_set[index_goal_0][0]
            self.goal_position[1] = goal_set[index_goal_0][1]
            self.goal_lock.release()

            robot_yaw = np.random.uniform(-1.0, 1.0, 1)
            self.model_state_req.model_state.pose.position.x = goal_set[index_robot_0][0]
            self.model_state_req.model_state.pose.position.y = goal_set[index_robot_0][1]
            z = sin(robot_yaw[0] / 2.0)
            w = cos(robot_yaw[0] / 2.0)
            self.model_state_req.model_state.pose.orientation.z = z
            self.model_state_req.model_state.pose.orientation.w = w

        if self.index == 1:
            self.goal_lock.acquire()
            self.goal_position[0] = goal_set[index_goal_1][0]
            self.goal_position[1] = goal_set[index_goal_1][1]
            self.goal_lock.release()

            robot_yaw = np.random.uniform(-1.0, 1.0, 1)
            self.model_state_req.model_state.pose.position.x = goal_set[index_robot_1][0]
            self.model_state_req.model_state.pose.position.y = goal_set[index_robot_1][1]
            z = sin(robot_yaw[0] / 2.0)
            w = cos(robot_yaw[0] / 2.0)
            self.model_state_req.model_state.pose.orientation.z = z
            self.model_state_req.model_state.pose.orientation.w = w

        self.reset_robot_state(episode)
        # randomly set goal position and robot states

        rospy.sleep(1.0)
        
        data = None
        while data is None:
            try:
                laser_topic = 'robot_' + str(self.index) +'/scan'
                data = rospy.wait_for_message(laser_topic, LaserScan, timeout=5)
            except:
                pass

        self.sub_goal_x = self.sub_goal_position[0]
        self.sub_goal_y = self.sub_goal_position[1]

        done, arrive = False, False
        self.used_scan, self.used_scan_low, linear_v, angular_v, done, arrive = self.getState(data)
        self.rel_dis_last = self.rel_dis
        self.linear_v_last = linear_v
        self.angular_v_last = angular_v

        dis_to_other0 = self.dis_to_other0
        # dis_to_other1 = self.dis_to_other1
        if dis_to_other0  > 2.0:
            dis_to_other0 = 2.0
        # if dis_to_other1  > 2.0:
        #     dis_to_other1 = 2.0
        
        state1 = self.used_scan / 1.5
        state2 = np.array([self.rel_dis / self.look_ahead, self.rel_theta / np.pi, linear_v, angular_v])

        return state1, state2

    def reset_robot_state(self, episode):
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')
            
        ###visual goal
        if episode > 0:
            rospy.wait_for_service('/gazebo/delete_model')
            self.del_model('target_'+ str(self.index) )

        #Build the target
        rospy.wait_for_service('/gazebo/spawn_sdf_model')
        try:
            goal_urdf = open(goal_model_dir, "r").read()
            target = SpawnModel
            target.model_name = 'target_'+ str(self.index)  # the same with sdf name
            target.model_xml = goal_urdf
            self.goal_position_pose.position.x = self.goal_position[0]
            self.goal_position_pose.position.y = self.goal_position[1]
            self.goal(target.model_name, target.model_xml, 'namespace', self.goal_position_pose, 'world')
        except (rospy.ServiceException) as e:
            print("/gazebo/failed to build the target")
        ###visual goal

        #set models pos from world
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')
