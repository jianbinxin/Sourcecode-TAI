1. prerequisites
tensorflow-gpu version >= 1.0
python verison >= 2.7
keras version >=2.0
ubuntu18.04 + ros melodic full desktop which includes Gazebo
Please download https://github.com/osrf/gazebo_models into ~/.gazebo/models
ros navigation packages which includes move_base, amcl, gampping

2. Multi-navigation system for Turtlebot3
Please install all the necessary packages for turtlebot3. 
For more information, follow exactly the guide from here: https://emanual.robotis.com/docs/en/platform/turtlebot3/setup/#setup

In case you don't want to hover over the link (only recommended for the pros), you can just simply follow these codes.
(Or using the RDS online)

`cd ~/catkin_ws/src/`

`git clone https://github.com/ROBOTIS-GIT/turtlebot3_msgs.git`

`git clone -b kinetic-devel https://github.com/ROBOTIS-GIT/turtlebot3.git`

`git clone https://github.com/ROBOTIS-GIT/turtlebot3_simulations.git`

`git clone https://github.com/syahmi001/multinav_turtlebot3.git`

`cd ~/catkin_ws && catkin_make`


3.参考rl_navigation中的launch文件配置你的launch 文件，以启动gazebo仿真环境和move_base功能包等：
(1) roslaunch rl_navigation turtlebot3_stage_x.launch


4. execute training and testing
internal policy：
(1) roslaunch rl_navigation turtlebot3_stage_1_move_base.launch
(2) python navigation_DQN_internal.py

external policy:
(1) roslaunch rl_navigation turtlebot3_stage_3_move_base.launch
(2) mpiexec -np 3 python multi_navigation_DQN_three.py


